"""
Module for gathering info from Wolf Heating System via ISM8 adapter
"""